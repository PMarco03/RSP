#ifndef RF24_UTILITY_INCLUDES_H_
#define RF24_UTILITY_INCLUDES_H_

#define RF24_SPIDEV

#include <cstring> // memcpy() used in RF24.cpp
#include "SPIDEV/RF24_arch_config.h"

#endif // RF24_UTILITY_INCLUDES_H_
